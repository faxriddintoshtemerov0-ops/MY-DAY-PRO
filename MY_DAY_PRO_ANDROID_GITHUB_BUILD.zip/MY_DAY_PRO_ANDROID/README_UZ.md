# MY DAY PRO — Android 1.0 manba kodi

Bu loyiha faqat Android APK uchun yozilgan native Kotlin ilovadir. WebView/PWA ishlatilmaydi.

## Hozirgi koddagi ishlaydigan qismlar
- Vazifa yaratish, ro‘yxatlash, bajarildi deb belgilash va o‘chirish.
- Vazifa nomi, sana/vaqt, ustuvorlik va bir martalik/kunlik/haftalik takrorlanish.
- Vazifa muddati kelganda Android bildirishnomasi.
- Vazifa bajarilmaguncha har 15 daqiqada eslatmani qayta rejalashtirish.
- Bildirishnomadagi **Bajarildi** tugmasi bilan eslatmani to‘xtatish.
- Bildirishnomadagi **10 daq. surish** tugmasi.
- Telefon qayta yoqilganda bajarilmagan vazifalar uchun signallarni tiklash.
- Maqsadlar, odatlar ro‘yxati va kundalik yozuvini qurilmada saqlash.
- Vazifalar statistikasi.
- Internet talab qilmaydigan mahalliy saqlash.

## APK yaratish
1. Android Studio o‘rnating va ushbu `MY_DAY_PRO_ANDROID` papkasini oching.
2. Gradle sync tugashini kuting. Internet kerak bo‘ladi, chunki Gradle kutubxonalarni yuklaydi.
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)` ni tanlang.
4. Sinov APK fayli odatda `app/build/outputs/apk/debug/app-debug.apk` ichida bo‘ladi.
5. Play Market uchun keyinchalik `Build > Generate Signed Bundle / APK` orqali imzolangan release AAB tayyorlanadi.

## Bildirishnomalar uchun muhim Android sozlamalari
- Android 13+ da ilova bildirishnoma ruxsatini so‘raydi; foydalanuvchi ruxsat berishi shart.
- Android 12+ da aniq vaqtli signal uchun ilova sozlamalarida **Alarms & reminders / Budilniklar va eslatmalar** ruxsatini yoqish talab qilinishi mumkin. Ilovadagi ruxsat tugmasi shu sozlamani ochadi.
- Telefon ishlab chiqaruvchisining batareya optimizatsiyasi, fon cheklovlari yoki foydalanuvchi ilovani **Force stop** qilishi bildirishnomalarni kechiktirishi/to‘xtatishi mumkin. Ilovaga fon ishlashiga ruxsat bering.
- Ilova o‘chirilsa, uning mahalliy ma’lumotlari va rejalashtirilgan signallari ham o‘chadi.

## Hozircha kiritilmagan / keyingi bosqich
- Premium to‘lovini Google Play Billing bilan ulash.
- Cloud hisob, server sinxronlash va bulut zaxirasi.
- Kalendar oynasining to‘liq oy/hafta ko‘rinishi.
- Ilova ichidagi dizaynni to‘liq hashamatli antik soat animatsiyasi bilan boyitish.
- Tahrirlash, qidirish, eksport/import va batafsil statistika.

Bu kod to‘liq tijoriy release yoki Play Market tasdig‘i deb hisoblanmaydi. Avval Android Studio’da build qilib, haqiqiy qurilmada ruxsatlar, qayta yuklanish va bildirishnomalarni sinash shart.
