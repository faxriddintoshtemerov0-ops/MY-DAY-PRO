package com.mydaypro.app

import android.Manifest
import android.app.*
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val bg = 0xFF171310.toInt()
    private val panel = 0xFF2B2119.toInt()
    private val gold = 0xFFD6AD58.toInt()
    private val cream = 0xFFF3E8D2.toInt()
    private val muted = 0xFFB9AA91.toInt()
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg
        ensureNotificationChannel(this)
        askNotificationPermission()
        ReminderScheduler.restore(this)
        showHome()
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 44)
        }
    }

    private fun base(title: String) {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(18,14,18,12) }
        val header = TextView(this).apply {
            text = "⏱  MY DAY PRO\n$title"; setTextColor(gold); textSize=22f; typeface=Typeface.create("serif",Typeface.BOLD); setPadding(4,8,4,16)
        }
        root.addView(header)
        val scroll = ScrollView(this)
        body = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        scroll.addView(body); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        val nav = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER; setPadding(0,10,0,0) }
        listOf("Reja","Maqsad","Odat","Kundalik","Statistika").forEach { label ->
            val b=Button(this).apply { text=label; textSize=10f; setTextColor(gold); setBackgroundColor(panel); isAllCaps=false; setOnClickListener { when(label){"Reja"->showHome();"Maqsad"->showCollection("goals","Maqsadlar");"Odat"->showCollection("habits","Odatlar");"Kundalik"->showJournal();else->showStats()} } }
            nav.addView(b,LinearLayout.LayoutParams(0,48,1f))
        }
        root.addView(nav); setContentView(root)
    }

    private fun text(s:String,size:Float=14f,color:Int=cream,bold:Boolean=false): TextView = TextView(this).apply {
        text=s; textSize=size; setTextColor(color); if(bold) typeface=Typeface.DEFAULT_BOLD; setPadding(8,8,8,8)
    }
    private fun button(s:String, action:()->Unit): Button = Button(this).apply {
        text=s; textSize=13f; isAllCaps=false; setTextColor(bg); setBackgroundColor(gold); setOnClickListener { action() }
    }
    private fun card(): LinearLayout = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(panel); setPadding(12,8,12,8) }

    private fun showHome() {
        base("Reja. Maqsad. Natija.")
        val tasks=TaskStore.all(this).sortedBy { it.dueAt }
        val done=tasks.count{it.done}; val total=tasks.size
        body.addView(text("Bugungi natija: $done / $total",16f,gold,true))
        val progress=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply { max=100; progress=if(total==0)0 else done*100/total }
        body.addView(progress,LinearLayout.LayoutParams(-1,12))
        body.addView(button("＋  Yangi vazifa qo‘shish") { addTaskDialog() },LinearLayout.LayoutParams(-1,52))
        body.addView(text("VAZIFALAR",13f,gold,true))
        if(tasks.isEmpty()) body.addView(text("Hozircha vazifalar yo‘q. Birinchi rejangizni qo‘shing.",14f,muted))
        tasks.forEach { task ->
            val box=card(); val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
            val info=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
            val date=SimpleDateFormat("dd.MM.yyyy  HH:mm",Locale.getDefault()).format(Date(task.dueAt))
            info.addView(text((if(task.done) "✓  " else "◷  ")+task.title,15f,if(task.done) muted else cream,true))
            info.addView(text("$date  •  ${task.priority}  •  ${if(task.repeat=="daily")"Har kuni" else if(task.repeat=="weekly")"Har hafta" else "Bir marta"}",10f,muted))
            row.addView(info,LinearLayout.LayoutParams(0,-2,1f))
            val doneBtn=Button(this).apply { text=if(task.done)"✓" else "Bajarildi"; textSize=10f; isAllCaps=false; setOnClickListener { TaskStore.markDone(this@MainActivity,task.id); ReminderScheduler.cancel(this@MainActivity,task.id); if(task.repeat!="none") TaskStore.pending(this@MainActivity).filter { it.title==task.title && it.repeat==task.repeat && it.dueAt>task.dueAt }.minByOrNull { it.dueAt }?.let { ReminderScheduler.schedule(this@MainActivity,it) }; showHome() } }
            row.addView(doneBtn)
            val del=Button(this).apply { text="×"; setOnClickListener { ReminderScheduler.cancel(this@MainActivity,task.id); TaskStore.delete(this@MainActivity,task.id); showHome() } }
            row.addView(del); box.addView(row); body.addView(box,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,7,0,7)})
        }
        body.addView(button("⏰  Eslatma ruxsatlarini sozlash") { ReminderScheduler.openExactAlarmSettings(this) },LinearLayout.LayoutParams(-1,48))
        body.addView(text("Eslatma: vazifa bajarilmaguncha 15 daqiqada takrorlanadi. Bildirishnomadagi ‘Bajarildi’ tugmasi takrorlashni to‘xtatadi.",11f,muted))
    }

    private fun addTaskDialog() {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,8,18,0) }
        val title=EditText(this).apply { hint="Vazifa nomi"; setTextColor(cream); setHintTextColor(muted) }; box.addView(title)
        val priority=Spinner(this); val priorities=listOf("Oddiy","O‘rta","Muhim","Juda muhim")
        priority.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,priorities); box.addView(priority)
        val repeat=Spinner(this); repeat.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("Bir marta","Har kuni","Har hafta")); box.addView(repeat)
        var chosen=Calendar.getInstance().apply { add(Calendar.HOUR,1); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0) }
        val whenBtn=Button(this).apply { isAllCaps=false; text="Vaqt: "+SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).format(chosen.time); setOnClickListener {
            DatePickerDialog(this@MainActivity,{_,y,m,d-> chosen.set(y,m,d); TimePickerDialog(this@MainActivity,{_,h,min->chosen.set(Calendar.HOUR_OF_DAY,h);chosen.set(Calendar.MINUTE,min);text="Vaqt: "+SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).format(chosen.time)},chosen.get(Calendar.HOUR_OF_DAY),chosen.get(Calendar.MINUTE),true).show()},chosen.get(Calendar.YEAR),chosen.get(Calendar.MONTH),chosen.get(Calendar.DAY_OF_MONTH)).show()
        } }; box.addView(whenBtn)
        AlertDialog.Builder(this).setTitle("Yangi vazifa").setView(box).setNegativeButton("Bekor qilish",null).setPositiveButton("Saqlash"){_,_->
            val name=title.text.toString().trim(); if(name.isNotEmpty()) {
                val rep=when(repeat.selectedItemPosition){1->"daily";2->"weekly";else->"none"}
                val task=TaskStore.add(this,name,chosen.timeInMillis,priorities[priority.selectedItemPosition],rep)
                ReminderScheduler.schedule(this,task)
                showHome()
            } else Toast.makeText(this,"Vazifa nomini kiriting",Toast.LENGTH_SHORT).show()
        }.show()
    }

    private fun showCollection(key:String, heading:String) {
        base(heading)
        val prefs=getSharedPreferences("my_day_pro_lists",MODE_PRIVATE)
        val list=mutableListOf<String>(); val a=org.json.JSONArray(prefs.getString(key,"[]")); for(i in 0 until a.length()) list.add(a.optString(i))
        body.addView(button("＋  $heading qo‘shish") {
            val input=EditText(this).apply { hint="Nomi" }
            AlertDialog.Builder(this).setTitle("Yangi element").setView(input).setNegativeButton("Bekor",null).setPositiveButton("Saqlash"){_,_->
                val value=input.text.toString().trim(); if(value.isNotEmpty()){list.add(value);saveList(prefs,key,list);showCollection(key,heading)}
            }.show()
        })
        if(list.isEmpty()) body.addView(text("Hozircha ma’lumot yo‘q. ‘Qo‘shish’ tugmasini bosing.",14f,muted))
        list.forEachIndexed { i,s ->
            val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setBackgroundColor(panel) }
            row.addView(text("•  $s",15f),LinearLayout.LayoutParams(0,-2,1f))
            row.addView(Button(this).apply{text="O‘chirish";setOnClickListener{list.removeAt(i);saveList(prefs,key,list);showCollection(key,heading)}})
            body.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,5,0,5)})
        }
    }
    private fun saveList(p:android.content.SharedPreferences,key:String,list:List<String>){val a=org.json.JSONArray();list.forEach{a.put(it)};p.edit().putString(key,a.toString()).apply()}

    private fun showJournal() {
        base("Kundalik")
        val prefs=getSharedPreferences("my_day_pro_lists",MODE_PRIVATE)
        val entry=EditText(this).apply { hint="Bugungi fikrlaringiz va xulosangiz..."; minLines=5; gravity=Gravity.TOP; setTextColor(cream); setHintTextColor(muted) }
        entry.setText(prefs.getString("journal_today","")); body.addView(entry)
        body.addView(button("Yozuvni saqlash") { prefs.edit().putString("journal_today",entry.text.toString()).apply(); Toast.makeText(this,"Kundalik saqlandi",Toast.LENGTH_SHORT).show() })
    }
    private fun showStats() {
        base("Statistika")
        val all=TaskStore.all(this); val done=all.count{it.done}; val pending=all.count{!it.done}
        body.addView(text("Umumiy vazifalar: ${all.size}",18f,gold,true))
        body.addView(text("Bajarilgan: $done",16f,cream)); body.addView(text("Kutilayotgan: $pending",16f,cream))
        val pct=if(all.isEmpty())0 else done*100/all.size
        body.addView(text("Bajarilish darajasi: $pct%",20f,gold,true))
        body.addView(ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progress=pct},LinearLayout.LayoutParams(-1,14))
    }
}
