package com.mydaypro.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Task(
    val id: String,
    val title: String,
    val dueAt: Long,
    val priority: String,
    val done: Boolean = false,
    val repeat: String = "none"
)

object TaskStore {
    private const val PREF = "my_day_pro_data"
    private const val TASKS = "tasks"
    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    @Synchronized fun all(c: Context): MutableList<Task> {
        val a = JSONArray(prefs(c).getString(TASKS, "[]"))
        val out = mutableListOf<Task>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            out.add(Task(o.optString("id"), o.optString("title"), o.optLong("dueAt"), o.optString("priority", "O‘rta"), o.optBoolean("done"), o.optString("repeat", "none")))
        }
        return out
    }

    @Synchronized fun saveAll(c: Context, tasks: List<Task>) {
        val a = JSONArray()
        tasks.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("dueAt", it.dueAt).put("priority", it.priority).put("done", it.done).put("repeat", it.repeat)) }
        prefs(c).edit().putString(TASKS, a.toString()).apply()
    }

    fun add(c: Context, title: String, dueAt: Long, priority: String, repeat: String): Task {
        val t = Task(UUID.randomUUID().toString(), title, dueAt, priority, false, repeat)
        val list = all(c); list.add(t); saveAll(c, list); return t
    }
    fun get(c: Context, id: String) = all(c).firstOrNull { it.id == id }
    fun markDone(c: Context, id: String) {
        val l=all(c); val i=l.indexOfFirst{it.id==id}
        if(i>=0) {
            val old=l[i]; l[i]=old.copy(done=true)
            if(old.repeat=="daily" || old.repeat=="weekly") {
                val step=if(old.repeat=="daily") 24L*60*60*1000 else 7L*24*60*60*1000
                l.add(old.copy(id=UUID.randomUUID().toString(), dueAt=old.dueAt+step, done=false))
            }
            saveAll(c,l)
        }
    }
    fun delete(c: Context, id: String) { saveAll(c, all(c).filterNot { it.id==id }) }
    fun pending(c: Context) = all(c).filter { !it.done }
}
