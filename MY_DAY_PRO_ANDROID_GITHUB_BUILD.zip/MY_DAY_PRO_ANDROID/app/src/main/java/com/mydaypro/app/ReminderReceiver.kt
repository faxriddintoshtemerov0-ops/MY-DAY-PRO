package com.mydaypro.app

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

const val CHANNEL_ID = "mydaypro_reminders"

fun ensureNotificationChannel(c: Context) {
    if (Build.VERSION.SDK_INT >= 26) {
        val nm = c.getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(CHANNEL_ID, "MY DAY PRO eslatmalari", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Vazifalar va takroriy eslatmalar"
            enableVibration(true)
        }
        nm.createNotificationChannel(channel)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra("task_id") ?: return
        val task = TaskStore.get(context, id) ?: return
        if (task.done) return
        ensureNotificationChannel(context)
        val open = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val doneIntent = Intent(context, DoneReceiver::class.java).putExtra("task_id", id)
        val donePi = PendingIntent.getBroadcast(context, id.hashCode()+1, doneIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val snoozeIntent = Intent(context, SnoozeReceiver::class.java).putExtra("task_id", id)
        val snoozePi = PendingIntent.getBroadcast(context, id.hashCode()+2, snoozeIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("MY DAY PRO • Eslatma")
            .setContentText(task.title)
            .setStyle(NotificationCompat.BigTextStyle().bigText("${task.title}\nVazifa bajarilmaguncha har 15 daqiqada eslatamiz."))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(open)
            .addAction(android.R.drawable.checkbox_on_background, "Bajarildi", donePi)
            .addAction(android.R.drawable.ic_lock_idle_alarm, "10 daq. surish", snoozePi)
            .build()
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id.hashCode(), n)
        // Each pending task is checked again in 15 minutes; completing it cancels the next alarm.
        ReminderScheduler.schedule(context, task, System.currentTimeMillis() + ReminderScheduler.INTERVAL)
    }
}

class DoneReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id=intent.getStringExtra("task_id") ?: return
        val old=TaskStore.get(context,id)
        TaskStore.markDone(context,id)
        ReminderScheduler.cancel(context,id)
        if(old!=null && old.repeat!="none") {
            TaskStore.pending(context).filter { it.title==old.title && it.repeat==old.repeat && it.dueAt>old.dueAt }.minByOrNull { it.dueAt }?.let { ReminderScheduler.schedule(context,it) }
        }
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(id.hashCode())
    }
}

class SnoozeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id=intent.getStringExtra("task_id") ?: return
        val task=TaskStore.get(context,id) ?: return
        if (!task.done) ReminderScheduler.schedule(context,task,System.currentTimeMillis()+10*60*1000L)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) ReminderScheduler.restore(context)
    }
}
