package com.mydaypro.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.net.Uri

object ReminderScheduler {
    const val INTERVAL = 15 * 60 * 1000L
    fun schedule(c: Context, task: Task, at: Long = task.dueAt) {
        if (task.done || at <= 0L) return
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val i = Intent(c, ReminderReceiver::class.java).putExtra("task_id", task.id)
        val pi = PendingIntent.getBroadcast(c, task.id.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val whenAt = maxOf(at, System.currentTimeMillis() + 1500L)
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenAt, pi)
                else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenAt, pi)
            } else am.setExact(AlarmManager.RTC_WAKEUP, whenAt, pi)
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenAt, pi)
        }
    }
    fun cancel(c: Context, id: String) {
        val i=Intent(c, ReminderReceiver::class.java)
        val pi=PendingIntent.getBroadcast(c,id.hashCode(),i,PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE) ?: return
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
        pi.cancel()
    }
    fun openExactAlarmSettings(c: Context) {
        if (Build.VERSION.SDK_INT >= 31) try {
            c.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${c.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {}
    }
    fun restore(c: Context) { TaskStore.pending(c).forEach { schedule(c, it, maxOf(it.dueAt, System.currentTimeMillis()+5000L)) } }
}
